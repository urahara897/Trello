package StepDefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Defination {
	WebDriver driver;   
	

	@Given("Open the browser and Navigate to Login Page")
	public void open_the_browser_and_navigate_to_login_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Downloads\\Compressed\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://trello.com/");
	 
	}
	@When("Enter valid username as {string}")
	public void enter_valid_username_as(String username) {
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@class='btn btn-sm btn-link text-primary']")).click();
		driver.findElement(By.xpath("//*[@class='google-button oauth-button']")).click();
		driver.findElement(By.xpath("//*[@id='identifierId']")).sendKeys(username);
		//Thread.sleep(10000);
		driver.findElement(By.className("VfPpkd-vQzf8d")).click();
	    
	}
	@When("Enter valid password as {string}")
	public void enter_valid_password_as(String password) {
		WebElement passwd = new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.name("password")));
		passwd.sendKeys(password);
	    
	}
	@When("Click on Login Button")
	public void click_on_login_button() {
		driver.findElement(By.className("VfPpkd-vQzf8d")).click();
	    
	}
	
	@When("Click on logout button")
	public void click_on_logout_button() throws InterruptedException {
		Thread.sleep(3000);
		WebElement lo = driver.findElement(By.xpath("//*[@data-test-id='header-member-menu-button']"));
		Actions act = new Actions(driver);
		act.moveToElement(lo).click().perform();
		WebElement lo1 = driver.findElement(By.xpath("//*[@data-test-id='header-member-menu-logout']"));
		act.moveToElement(lo1).click().perform();
		WebElement lo2 = driver.findElement(By.xpath("//*[@id='logout-submit']"));
		act.moveToElement(lo2).click().perform();
		driver.close();
	    
	}
	
	@When("Enter invalid username as {string}")
	public void enter_invalid_username_as(String username) {
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@class='btn btn-sm btn-link text-primary']")).click();
		driver.findElement(By.xpath("//*[@class='google-button oauth-button']")).click();
		driver.findElement(By.xpath("//*[@id='identifierId']")).sendKeys(username);
		//Thread.sleep(10000);
		driver.findElement(By.className("VfPpkd-vQzf8d")).click();
		driver.close();
	    
	}
	
	
	

	
	
}
