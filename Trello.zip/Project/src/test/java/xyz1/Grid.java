package xyz1;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Grid {
    
	WebDriver driver;
	
	
	@BeforeTest
	public void BT() throws MalformedURLException {
		
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		ChromeOptions options = new ChromeOptions();
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Downloads\\Compressed\\chromedriver_win32\\chromedriver.exe");
		//driver = new ChromeDriver();
		driver = new RemoteWebDriver(new URL("http://192.168.1.26:4444/wd/hub"),cap);
		//driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://trello.com/");
		
		
	}
	
	@Test(priority=0)
	public void Login() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@class='btn btn-sm btn-link text-primary']")).click();
		driver.findElement(By.xpath("//*[@class='google-button oauth-button']")).click();
		driver.findElement(By.xpath("//*[@id='identifierId']")).sendKeys("Enter mail id");
		//Thread.sleep(10000);
		driver.findElement(By.className("VfPpkd-vQzf8d")).click();
		//Thread.sleep(10000);
		//driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Enter password");
		WebElement password = new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.name("password")));
		password.sendKeys("Enter password");
		driver.findElement(By.className("VfPpkd-vQzf8d")).click();
		
	}
	
	@Test(priority = 1)
	public void CreateBoard() throws InterruptedException {
		
		
		
		WebDriverWait wait = new WebDriverWait(driver,40);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("_1N9LJYg3C9x47Y")));
		//new WebDriverWait(driver, timeout).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.id("checkoutLink")));
		driver.findElement(By.className("_1N9LJYg3C9x47Y")).click();
		//driver.findElement(By.className("_1N9LJYg3C9x47Y")).click();
		driver.findElement(By.className("M91aWYFMf7mrFf")).click();
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("nch-textfield__input _2N2CjUFKhgeXLO _2N2CjUFKhgeXLO _3pXGTS3_pwahBt")));
		driver.findElement(By.className("_34UgjJGHhRxDQr")).sendKeys("Demo");
		driver.findElement(By.xpath("//*[@class='_2NEPrwhDnsG_qO _3TTqkG5muwOzqZ _3Ik0JLsERwh6Ui _1Tu9wiuW4Te8Rx']")).click();
		
	}

	@Test(priority = 2)
	public void AddCard() throws InterruptedException {
		
		/*WebDriverWait wait = new WebDriverWait(driver,40);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("_1N9LJYg3C9x47Y")));
		//new WebDriverWait(driver, timeout).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.id("checkoutLink")));
		driver.findElement(By.className("_1N9LJYg3C9x47Y")).click();
		//driver.findElement(By.className("_1N9LJYg3C9x47Y")).click();
		driver.findElement(By.className("M91aWYFMf7mrFf")).click();
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("nch-textfield__input _2N2CjUFKhgeXLO _2N2CjUFKhgeXLO _3pXGTS3_pwahBt")));
		driver.findElement(By.className("_34UgjJGHhRxDQr")).sendKeys("Demo");
		driver.findElement(By.xpath("//*[@class='_2NEPrwhDnsG_qO _3TTqkG5muwOzqZ _3Ik0JLsERwh6Ui _1Tu9wiuW4Te8Rx']")).click();
		//driver.findElement(By.className("list-name-input")).sendKeys("abc");
		//driver.findElement(By.xpath("//*[@class='nch-button nch-button--primary mod-list-add-button js-save-edit']")).click();
		//driver.findElement(By.xpath("//span[@class='js-add-a-card']")).click();
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("list-card-composer-textarea js-card-title")));*/
		driver.findElement(By.xpath("//*[@placeholder='Enter a title for this card�']")).sendKeys("abc");
		driver.findElement(By.xpath("//*[@class='nch-button nch-button--primary confirm mod-compact js-add-card']")).click();
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='_14TyY7wB85QoVU']")));
		WebElement log = driver.findElement(By.className("_14TyY7wB85QoVU"));
		Actions act = new Actions(driver);
		act.moveToElement(log).click().perform();
		Thread.sleep(4000);
		
		
	}
	
	@Test(priority = 3)
	public void DeleteBoard() throws InterruptedException {
		Actions act = new Actions(driver);
		driver.findElement(By.linkText("Show menu")).click();
		//driver.findElement(By.partialLinkText("&nbsp;More")).click();
		driver.findElement(By.xpath("//*[@class='board-menu-navigation-item-link js-open-more']")).click();
		driver.findElement(By.xpath("//*[@class='board-menu-navigation-item-link js-close-board']")).click();
		//driver.switchTo().frame("pop-over is-shown");
		WebElement dialog = driver.findElement(By.xpath("//*[@type='submit' and @value= 'Close']"));
		act.moveToElement(dialog).click().perform();
		Thread.sleep(4000);
		WebElement delpop = driver.findElement(By.xpath("//*[@data-test-id='close-board-delete-board-button']"));
		act.moveToElement(delpop).click().perform();
		WebElement del = driver.findElement(By.xpath("//*[@data-test-id='close-board-delete-board-confirm-button']"));
		act.moveToElement(del).click().perform();
		
	}
	
	
	@Test(priority = 4)
	public void Logout() throws InterruptedException {
		
		
		
		
		WebElement lo = driver.findElement(By.xpath("//*[@data-test-id='header-member-menu-button']"));
		Actions act = new Actions(driver);
		act.moveToElement(lo).click().perform();
		WebElement lo1 = driver.findElement(By.xpath("//*[@data-test-id='header-member-menu-logout']"));
		act.moveToElement(lo1).click().perform();
		WebElement lo2 = driver.findElement(By.xpath("//*[@id='logout-submit']"));
		act.moveToElement(lo2).click().perform();
		
	}
	
	
	@AfterTest
	public void AT() {
		
		driver.close();
		
	}
	
}
