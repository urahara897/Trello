package Runner;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
@CucumberOptions(features= {"src//test//resources//Login//pqr.feature"},
glue = {"StepDefination"},
dryRun=false,//check all methods implemented
monochrome = true,//will give a report format properly in console
//tags = "@NegativeTesting",
plugin = {"html:testoutput/rudro.html","junit:testoutput/rudro.xml","json:testoutput/sunil.json"}

		)             
public class Test_Runner {
}
